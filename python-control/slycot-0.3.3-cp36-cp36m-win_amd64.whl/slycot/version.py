
# THIS FILE IS GENERATED FROM SLYCOT SETUP.PY
short_version = '0.3.3'
version = '0.3.3'
full_version = '0.3.3'
git_revision = 'bf4765d4cfcafa639d3eaa8e70b80c2bc2cd34fa'
release = True

if not release:
    version = full_version
